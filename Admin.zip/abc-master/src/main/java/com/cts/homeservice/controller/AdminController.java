package com.cts.homeservice.controller;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cts.homeservice.bean.Requests;
import com.cts.homeservice.bean.Worker;
import com.cts.homeservice.service.LocationService;
import com.cts.homeservice.service.RequestsService;
import com.cts.homeservice.service.WorkerService;

@Controller
public class AdminController {
	
	@Autowired
	private RequestsService requestsService;
	
	@Autowired
	private LocationService locationService;
	
	@Autowired
	private WorkerService workerService;
	
	

	@GetMapping("adminPanel.html")
	public String getAdminPanel() {
		return "adminPanel";
	}
	
	@GetMapping("adminPanelRequest.html")
	public ModelAndView getRequestPage() {
		ModelAndView modelAndView = new ModelAndView();
		
		modelAndView.addObject("requestList",requestsService.getAllRequests());
		
		modelAndView.setViewName("adminPanelRequest");
		return modelAndView;
	}
	
	@GetMapping("adminAssignTask.html")
	public ModelAndView getAdminAssignTask(@RequestParam("requestId") int requestId) throws JSONException, IOException, ParseException {
		ModelAndView modelAndView = new ModelAndView();
		
		//modelAndView.addObject("workerList",);

		Requests requests = requestsService.getRequestById(requestId);
		
		String locality = requests.getLocality();
		String serviceType = requests.getServiceType();
		String latLong = locationService.getLatLong(locality);
		String vicinity = locationService.getVicinity(latLong).trim();
		List<Worker> workers = workerService.getWorkerByLocalityAndService(vicinity,serviceType);
		System.out.println(workers);
		modelAndView.addObject("workerList", workers);		
		
		modelAndView.setViewName("adminAssignTask");
		return modelAndView;
	}
	
	@PostMapping("adminAssignTask.html")
	public ModelAndView assignWorker(HttpServletRequest request) {
		int workerId = Integer.parseInt(request.getParameter("workerId"));
		
		ModelAndView modelAndView = new ModelAndView();
		System.out.println(workerId + "wrpker");
		modelAndView.setViewName("adminAssignTask");
		return modelAndView;
	}
}
