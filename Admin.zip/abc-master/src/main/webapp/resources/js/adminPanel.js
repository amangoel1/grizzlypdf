
/* sidebar functions */

function openSidebar() {
        document.getElementById("mySidenav").style.width = "250px";
  }

  function closeSidebar() {
        document.getElementById("mySidenav").style.width = "0px";
  }